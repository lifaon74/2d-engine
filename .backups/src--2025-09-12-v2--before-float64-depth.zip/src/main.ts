import { createCanvasRenderingContext2d } from './helpers/create-canvas-rendering-context-2d';
import { displayCanvas } from './helpers/display-canvas';
import { imageUrlToImageData } from './helpers/image-url-to-image-data';
import { scaleCanvas } from './helpers/scale-canvas';
import { clampImageDepth } from './image-with-depth/clamp-image-depth';
import { ImageWithDepth } from './image-with-depth/image-with-depth';

export interface RendererImageElement {
  readonly x: number;
  readonly y: number;
  readonly z: number;
  readonly image: ImageWithDepth;
}

export class CPUImageRenderer {
  readonly #width: number;
  readonly #height: number;
  #x: number;
  #y: number;

  #elements: readonly RendererImageElement[];
  readonly #opaqueLayer: ImageWithDepth;
  readonly #transparentLayers: readonly ImageWithDepth[];
  readonly #transparentLayersLength: Uint8Array;
  readonly #output: ImageData;

  constructor(width: number, height: number) {
    this.#width = width;
    this.#height = height;

    this.#x = 0;
    this.#y = 0;

    this.#elements = [];
    this.#opaqueLayer = new ImageWithDepth(width, height);
    this.#transparentLayers = Array.from(
      { length: 10 },
      (): ImageWithDepth => new ImageWithDepth(width, height),
    );
    this.#transparentLayersLength = new Uint8Array(width * height);
    this.#output = new ImageData(width, height);
  }

  /* VIEW */

  get width(): number {
    return this.#width;
  }

  get height(): number {
    return this.#height;
  }

  get x(): number {
    return this.#x;
  }

  get y(): number {
    return this.#y;
  }

  setView(x: number, y: number): void {
    this.#x = x;
    this.#y = y;
  }

  /* ELEMENTS */

  get elements(): readonly RendererImageElement[] {
    return this.#elements;
  }

  setElements(value: readonly RendererImageElement[]) {
    this.#elements = value;
  }

  /* LAYERS */

  // get layers(): readonly ImageWithDepth[] {
  //   return this.#transparentLayers;
  // }

  #clearLayers(): void {
    this.#opaqueLayer.data.fill(0);

    this.#transparentLayersLength.fill(0);

    for (let i: number = 0; i < this.#transparentLayers.length; i++) {
      this.#transparentLayers[i].data.fill(0);
      this.#transparentLayers[i].depth.fill(0);
    }
  }

  renderLayers(): void {
    this.#clearLayers();

    for (let i: number = 0; i < this.#elements.length; i++) {
      const element: RendererImageElement = this.#elements[i];

      const x_delta: number = element.x - this.#x;
      const x_viewport_start: number = Math.max(0, Math.min(this.#width, x_delta));
      const x_viewport_end: number = Math.max(
        0,
        Math.min(this.#width, x_delta + element.image.width),
      );

      const y_delta: number = element.y - this.#y;
      const y_viewport_start: number = Math.max(0, Math.min(this.#height, y_delta));
      const y_viewport_end: number = Math.max(
        0,
        Math.min(this.#height, y_delta + element.image.height),
      );

      // const z_element: number = Math.max(0, Math.min(0xffff, element.z));
      // const z_element: number = element.z;

      for (let x_viewport: number = x_viewport_start; x_viewport < x_viewport_end; x_viewport++) {
        const x_element: number = x_viewport - x_delta;

        for (let y_viewport: number = y_viewport_start; y_viewport < y_viewport_end; y_viewport++) {
          const y_element: number = y_viewport - y_delta;

          const i_viewport: number = x_viewport + y_viewport * this.#width;
          const i_viewport_data: number = i_viewport * 4;

          const i_element: number = x_element + y_element * element.image.width;
          const i_element_data: number = i_element * 4;

          const alpha_element: number = element.image.data[i_element_data + 3];

          if (alpha_element === 0) {
            // the element's pixel is fully transparent
            // => skip pixel's rendering
            continue;
          }

          const depth_element: number = element.z + element.image.depth[i_element];

          const alpha_opaque_layer: number = this.#opaqueLayer.data[i_viewport_data + 3];
          const depth_opaque_layer: number = this.#opaqueLayer.depth[i_viewport];

          if (alpha_opaque_layer === 0 || depth_element >= depth_opaque_layer) {
            // the element's pixel is above the opaque-layer's pixel

            const depth_element_clamped: number = clampImageDepth(depth_element);

            if (alpha_element === 0xff) {
              // the element's pixel is opaque

              // set rgba
              for (let i: number = 0; i < 4; i++) {
                this.#opaqueLayer.data[i_viewport_data + i] =
                  element.image.data[i_element_data + i];
              }

              // this.#opaqueLayer.data[i_viewport_data] = element.image.data[i_element_data];
              // this.#opaqueLayer.data[i_viewport_data + 1] = element.image.data[i_element_data + 1];
              // this.#opaqueLayer.data[i_viewport_data + 2] = element.image.data[i_element_data + 2];
              // this.#opaqueLayer.data[i_viewport_data + 3] = alpha_element;

              this.#opaqueLayer.depth[i_viewport] = depth_element_clamped;
              // TODO must cleanup every transparentLayers that are below the new opaque layer's depth
            } else {
              // the element's pixel is transparent

              if (depth_element_clamped === depth_opaque_layer && alpha_opaque_layer !== 0) {
                // the element's pixel merges with the opaque-layer's pixel
                // => alpha blending
                const alpha: number = 1 - alpha_element / 0xff;

                // set rgb (note: a is always 1)
                for (let i: number = 0; i < 3; i++) {
                  this.#opaqueLayer.data[i_viewport_data + i] =
                    this.#opaqueLayer.data[i_viewport_data + i] * alpha +
                    element.image.data[i_element_data + i];
                }
                // this.#opaqueLayer.data[i_viewport_data] =
                //   this.#opaqueLayer.data[i_viewport_data] * alpha +
                //   element.image.data[i_element_data];
                // this.#opaqueLayer.data[i_viewport_data + 1] =
                //   this.#opaqueLayer.data[i_viewport_data + 1] * alpha +
                //   element.image.data[i_element_data + 1];
                // this.#opaqueLayer.data[i_viewport_data + 2] =
                //   this.#opaqueLayer.data[i_viewport_data + 2] * alpha +
                //   element.image.data[i_element_data + 2];
              } else {
                // TODO
                this.#transparentLayers[0].data[i_viewport_data] =
                  element.image.data[i_element_data];
                this.#transparentLayers[0].data[i_viewport_data + 1] =
                  element.image.data[i_element_data + 1];
                this.#transparentLayers[0].data[i_viewport_data + 2] =
                  element.image.data[i_element_data + 2];
                this.#transparentLayers[0].data[i_viewport_data + 3] =
                  element.image.data[i_element_data + 3];
                this.#transparentLayersLength[i_viewport] = 1;
              }
            }
          }
          // {else} the element's pixel is below the opaque-layer's pixel
          // => skip pixel's rendering
        }
      }
    }
  }

  /* OUTPUT */

  get output(): ImageData {
    return this.#output;
  }

  #clearOutput(): void {
    this.#output.data.fill(0);
  }

  renderOutput(): void {
    this.#output.data.set(this.#opaqueLayer.data);

    for (let x_viewport: number = 0; x_viewport < this.#width; x_viewport++) {
      for (let y_viewport: number = 0; y_viewport < this.#height; y_viewport++) {
        const i_viewport: number = x_viewport + y_viewport * this.#width;
        const i_viewport_data: number = i_viewport * 4;

        const length_transparent_layers: number = this.#transparentLayersLength[i_viewport];

        for (
          let i_transparent_layer: number = 0;
          i_transparent_layer < length_transparent_layers;
          i_transparent_layer++
        ) {
          const data_layer: Uint8ClampedArray = this.#transparentLayers[i_transparent_layer].data;

          const alpha: number = 1 - data_layer[i_viewport_data + 3] / 0xff;

          for (let i: number = 0; i < 4; i++) {
            this.#output.data[i_viewport_data + i] =
              this.#output.data[i_viewport_data + i] * alpha + data_layer[i_viewport_data + i];
          }
        }
      }
    }
  }
}

/*------*/

async function loadTree00(): Promise<ImageWithDepth> {
  return ImageWithDepth.fromImageData(
    await imageUrlToImageData(new URL('../assets/tree-00.png?url', import.meta.url)),
  );
}

// async function loadTree01(): Promise<ImageWithDepth> {
//   return ImageWithDepth.fromImageData(
//     await imageUrlToImageData(new URL('../assets/tree-01.png', import.meta.url)),
//   );
// }

/*------*/

async function debug_01() {
  const renderer: CPUImageRenderer = new CPUImageRenderer(256, 256);

  renderer.setView(0, 0);

  const ctx = createCanvasRenderingContext2d(renderer.width, renderer.height);
  scaleCanvas(ctx.canvas, 1);
  displayCanvas(ctx.canvas);

  const tree00: ImageWithDepth = await loadTree00();

  renderer.setElements([
    {
      x: 16,
      y: 16,
      z: 32,
      image: tree00,
    },
    {
      x: 48,
      y: 0,
      z: 16,
      image: tree00,
    },
  ]);

  renderer.renderLayers();
  renderer.renderOutput();

  ctx.putImageData(renderer.output, 0, 0);
}

async function main() {
  // await debug_00();
  await debug_01();
}

main();
