export class ImageWithDepth {
  static fromImageData(imageData: ImageData, depth?: Uint16Array): ImageWithDepth {
    return new ImageWithDepth(imageData.width, imageData.height, imageData.data, depth);
  }

  readonly width: number;
  readonly height: number;

  readonly data: Uint8ClampedArray;
  readonly depth: Uint16Array;

  constructor(width: number, height: number, data?: Uint8ClampedArray, depth?: Uint16Array) {
    const depthLength: number = width * height;
    const dataLength: number = depthLength * 4;

    if (data === undefined) {
      data = new Uint8ClampedArray(dataLength);
    } else if (data.length !== dataLength) {
      throw new Error(`data should have a length of ${dataLength} (width * height * 4)`);
    }

    if (depth === undefined) {
      depth = new Uint16Array(depthLength);
    } else if (depth.length !== depthLength) {
      throw new Error(`zBuffer should have a length of ${depthLength} (width * height)`);
    }

    this.width = width;
    this.height = height;
    this.data = data;
    this.depth = depth;
  }
}
