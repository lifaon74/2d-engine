export function clampImageDepth(depth: number): number {
  return Math.max(0, Math.min(0xffff, depth)) | 0;
}
