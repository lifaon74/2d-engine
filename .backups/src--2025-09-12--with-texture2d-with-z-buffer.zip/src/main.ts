import { createCanvasRenderingContext2d } from './helpers/create-canvas-rendering-context-2d';
import { displayCanvas } from './helpers/display-canvas';
import { download } from './helpers/download';
import { imageUrlToImageData } from './helpers/image-url-to-image-data';
import { scaleCanvas } from './helpers/scale-canvas';
import { Texture2dWithZBuffer } from './texture/texture2d-with-z-buffer';

export function trace_direct_light_2d(
  light_x: number,
  light_y: number,
  light_radius: number,
  light_start_angle: number,
  light_angle: number,
  segments: Float32Array, // [...point=[x0, y0, x1, y1], ...]
): Float32Array {}

async function debug_01() {}

async function main() {
  // await debug_00();
  await debug_01();
}

main();
